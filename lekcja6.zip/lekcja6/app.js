class Message extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            messageIsActive: false
        }
        this.handleMessageButton = this.handleMessageButton.bind(this)
    }

    handleMessageButton() {
        this.setState((prevState) => ({
            messageIsActive: !prevState.messageIsActive
        }));
    }

    render() {
        console.log(this.state.messageIsActive);
        const text = 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quia, iure similique minima doloremque voluptates itaque repudiandae, deserunt cum nisi laborum porro? Facilis dignissimos recusandae obcaecati reiciendis voluptas, consectetur nihil eos.'

        return (
            <>
                <button onClick={this.handleMessageButton}>
                    {this.state.messageIsActive ? 'Ukryj' : 'Pokaz'}
                    {/* {this.state.messageIsActive && <p>{text}</p>} */}
                </button>
                {
                    this.state.messageIsActive ? <p>{text}</p> : null
                }

            </>
        )
    }
}

ReactDOM.render(<Message />, document.getElementById('root'));