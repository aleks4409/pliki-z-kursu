class MyApp extends React.Component {
    render() {
        return (
            <>
                <div className="main">
                    <div className="card1">
                        <h1 className="imie">Cześć, <br />mam na imię Aleks</h1>

                    </div>

                    <div className="card2">
                        <h1 className="imie2">Jestem programistą <br />i kocham kodować</h1>
                        {/* stopka */}
                        <div className="footer">
                            <div className="footerCard1">
                                <label></label>
                            </div>
                            <div className="footerCard2">
                                <label></label>
                            </div>
                            <div className="footerCard3">
                                <label></label>
                            </div>
                            <div className="footerCard4">
                                <label></label>
                            </div>
                        </div>
                        {/* stopka */}
                    </div>
                </div>
            </>
        )

    }
}

ReactDOM.render(<MyApp />, document.getElementById('root'));