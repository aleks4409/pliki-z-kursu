const Person = (props) => {
    return (
        <li>
            <span>{props.name}</span>
            <button onClick={props.delete}>Usuń</button>
        </li>
    )
}

class List extends React.Component {

    state = {
        people: [
            {
                id: 1,
                name: 'Jan',
            },
            {
                id: 2,
                name: 'Aleks',
            },
            {
                id: 3,
                name: 'Adam',
            },
            {
                id: 4,
                name: 'Marek',
            },
        ]
    }

    handleDelete(id) {
        //console.log(this, id);
        const people = [...this.state.people];//dokonujemy kopi tablicy za pomocą "spread (...)"
        const index = people.findIndex(person => person.id === id)
        people.splice(index, 1)
        this.setState({
            people
        })
    }
    render() {

        const people = this.state.people.map(person => (
            <Person
                key={person.id}
                name={person.name}
                delete={this.handleDelete.bind(this, person.id)}
            />)
        )

        return (
            <>
                <ul>
                    {people}
                </ul>
            </>
        )
    }
}

ReactDOM.render(<List />, document.getElementById('root'))