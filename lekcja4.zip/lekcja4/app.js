// Przycisk - po kliknienciu dodawana literka do tekstu
// najpierw plan a potem logika
class App extends React.Component {
    // constructor(props) {
    //     super(props);
    //     this.state = {
    //         text: "",
    //     }
    // }

    state = {
        text: "",
        btn: "uruchom",
    }

    handleClick = () => {
        //this.state.text += "a"; -- tak sie tego nie robi
        const number = Math.floor(Math.random(1) * 10) + 1;

        // this.setState({
        //     text: this.state.text + letter
        // })

        this.setState(() => ({
            text: this.state.text + number
        })
        )
    }
    render() {
        const btnName = "Stwórz liczbę"
        return (
            <>
                <button onClick={this.handleClick.bind(this)}>{btnName}</button>
                <PanelResult text={this.state.text} />
            </>
        )
    }
}

const PanelResult = (props) => {
    return (
        <h1>{props.text}</h1>
    )
}

ReactDOM.render(<App btnTitle="Dodacj cyfrę" />, document.getElementById('root'))