


const ValidationMessage = (props) =>{
    const {txt} = props
    return(
        <p>{txt}</p>
    )
    
} ;

const OrderForm = (props) => {
    const {submit, isConfirmed, change} = props;
    return(
        <form action="" onSubmit={submit}>
        <input type="checkbox" id="age" onChange={change} checked={isConfirmed}/>
        <label htmlFor="age">Mam co najmniej 16 lat</label><br />
        <button type="submit">Kup Bilet</button>
        </form>
    )
}
class TicketShop extends React.Component{
    state ={
        isConfirmed: false,
        isFormSubmitted: false,
    }
    handleCheckboxChange = () => {
        this.setState({
            isConfirmed: !this.state.isConfirmed,
            isFormSubmitted: false
        })
    }

    handleForSubmit = (e) => {
        e.preventDefault();
        if(!this.isFormSubmitted){
            this.setState({
                isFormSubmitted: true
            })
        }
    }

    displayMessage = () => {
        if(this.state.isFormSubmitted){
            if(this.state.isConfirmed){
                return <ValidationMessage txt="Mozesz obejrzeć film." />
            }else{
                return <ValidationMessage txt="Nie moesz obejrzeć tego filmu jeśli masz mniej niz 16 lat." />
            }
        }else{
            return null;
        }
        
    }
    render(){

        const {isConfirmed, isFormSubmitted} = this.state


        return(
            <>
            <h1>Kup Bilet na horror roku!</h1>
            <OrderForm

            change={this.handleCheckboxChange} 
            submit={this.handleForSubmit}
            checked={isConfirmed}

            />
            {this.displayMessage()}
            </>
        )
    }
}

ReactDOM.render(<TicketShop />, document.getElementById("root"))