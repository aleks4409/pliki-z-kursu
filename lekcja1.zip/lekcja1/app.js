// // console.log(React);
// // console.log(ReactDOM);

// const element = <div>Pierwszy element react</div>
// //tak jak na dole się nie pisze lepije uyć jsx tak jak jest na gorze
// const element2 = React.createElement(
//     "div",
//     null,
//     "Pierwszy element react"
// )

// const element3 = (
//     <div>
//         <p className="red">Tekst</p>
//     </div>
// )//nie wolno uzywac samego class trzeba className

// const element4 = <div><p>Tekst</p></div>
// //w elementach musi być 1! nadrzędny element bo inaczej będzie błąd!
// const element5 = (
//     <>
//         <section></section>
//         <section></section>
//     </>
// )


const header = <h1 className="title">Witaj na stronie</h1>

const classBig = "big";

const handleClick = () => alert("klik");
const main = (
    <div>
        <h1 onClick={handleClick} className="red">Pierwszy artykuł</h1>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Similique quas expedita hic eaque numquam eligendi pariatur reprehenderit! Quidem iste expedita quo nihil. Id reiciendis laborum fugit. Nobis pariatur tenetur quidem.</p>

    </div>
)
const text = "stopkaaa";
const largeText = "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Culpa, a quod suscipit repudiandae corrupti sapiente officiis totam veritatis quam autem voluptas ducimus vel provident id placeat, nihil consectetur atque facere!"
const footer = (
    <footer>
        <p className={classBig}>{text}</p>
        {largeText}
    </footer>
)

const app = [header, main, footer];

ReactDOM.render(app, document.getElementById('root'));

