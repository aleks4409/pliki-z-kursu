class App extends React.Component {
    constructor(props) {
        super(props)
        this.stete = {
            number: 0
        }
        console.log("constructor")
    }

    componentWillMount() {
        console.log("WillMount")
    }
    componentDidMount() {
        console.log("DidMount")
        this.setStete({
            number: 1
        })
    }
    render() {
        return (
            <p>
                lifecycle - montowanie komponentu
            </p>
        )
    }
}

class Child extends React.Component {
    componentDidMount() {
        console.log("DidMount")
    }
    render() {
        return (
            <p>dziecko</p>
        )
    }
}

ReactDOM.render(<App />, document.getElementById('root'))